/*
File Name: main.cpp
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This main.cpp file was developed for part A of the Sudoku project. The main
objective of this file is to get a sudoku file input from the user. 
From the user input the board class is able to initialize a 
sodoku board and print the conflicts in the rows, columns, and squares. 
The main file can also tell if the current sudoku grid is solved or unsolved.

NOTE: At this stage in the process no boards are currently solved
*/



// Include statements
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <string>

#include "board.h"

using namespace std;



int main()
// Main function to meet the requirements of the Sudoku project Part A
{
	// String to store input filename
	string inputSudokuFile;

	// Input file object
	ifstream fin;

	// bool for storing if the board is fully solved
	bool isSolved;

	cout << "Welcome to the Sudoku Game!\n\n";

	// Output to console to ask user to enter .txt filename
	// NOTE: This file must be located in the same directory as this C++ file
	cout << "Please enter the name of the Grid File that should be used. "
		 << "Please ensure file is located in same folder as this CPP file "
		 << "and contains the filename along with the .txt extension: ";

	cin >> inputSudokuFile;

	cout << "\n\n";

	// Open input from inputSudokuFile
	fin.open(inputSudokuFile.c_str());

	while (!fin)
	// Error checking to see if input file is valid
	{
		// If not valid, user if forced to keep entering file until entry is
		// valid
		cout << "File name entered is not valid. Please try again: ";
		cin >> inputSudokuFile;

		fin.open(inputSudokuFile.c_str());
	}// End while

	Board mainSudokuBoard;

	int numBoardsInFile = 0;

	while (fin && fin.peek() != 'Z')
	// Checks to ensure sudoku grid(s) data is/are present and that the end of 
	// file	character (Z) is not present as the next character from the current
	// one
	{
		numBoardsInFile++;

		cout << "********************************************************";
		cout << "\nBoard #" << numBoardsInFile << "\n\n";

		// Clears the board incase there is more than one grid in an input file
		mainSudokuBoard.clear();
		
		// Loads known values into the grid
		mainSudokuBoard.initialize(fin);

		// Prints grid to the console
		mainSudokuBoard.print();

		// Prints conflict grids to the console
		mainSudokuBoard.printConflicts();

		// Checks to see if the board has been solved
		isSolved = mainSudokuBoard.fullySolved();

		if (isSolved)
		// Prints that the board has been solved if isSolved == true
		{
			cout << "\n\nBased on the above information, sudoku board" 
				 << " #" << numBoardsInFile << " has been fully solved!\n" 
				 << "********************************************************"
				 << "\n\n\n";
		}
		else
		// Prints that the board has not been solved if isSolved == false
		{
			cout << "\n\nBased on the above information, sudoku board"
				 << " #" << numBoardsInFile << " is not solved.\n"
				 << "********************************************************"
				 << "\n\n\n";
		}// End if
	}// End while

	return 0;
}// End main() function

// End main.cpp