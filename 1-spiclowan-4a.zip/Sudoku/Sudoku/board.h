/*
File Name: board.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This board.h file was developed for part A of the Sudoku project. The main
objective of this file is to initialize and print a sudoku game. 

This consisted of:
1. Setting the size of the board and values
2. Printing the board that was read from a .txt file into a matrix 
3. Updating a conflict counter for rows, columns, and squares
4. Checking if a cell is blank
5. Printing out conflicts for rows, columns, and squares
6. Setting a cell to a value as well as resetting a cell
7. Checking if the sudoku board is fully solved

A conflict means a number has been placed. The digits range from 1-9.
A 0 represents a specific digit does not coflict in the row, column, or square,
while a 1 represents a specific digit is in the row, column, or square

NOTE: Some of these methods were borrowed from the board.cpp file provided on
Canvas with the project. These will be noted with "<FROM CANVAS>"
*/

// Include statements
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <string>
#include <list>
#include <fstream>
#include <limits.h>

#include "d_matrix.h"
#include "d_except.h"

using namespace std;

// The number of cells in a small square (assumed to be fixed at 3) in a given
// row or column. The board has SQUARE_SIZE^2 rows and SQUARE_SIZE^2 columns
const int SQUARE_SIZE = 3;

// Board size to get the number of rows and columns, since the sudoku grid is
// an nxn grid
const int BOARD_SIZE = SQUARE_SIZE * SQUARE_SIZE;

// Lowest valid value in Sudoku Grid
const int MIN_GRID_VAL = 1;
const int MAX_GRID_VAL = 9;

// Tracks the number of solutions for a given grid
// int numSolutions = 0;

// Value used to represent a blank cell in the sudoku grid
const int BLANK_GRID_CELL_VAL = -1;



class Board
{
	// Public members of Board Class
	public:
		// Default constructor
		Board();

		// Clears a grid with empty values in each cell
		void clear();

		// Prints board in a nice, neat grid to the console
		void print();

		// Initialize a sudoku board with BOARD_SIZE * BOARD_SIZE values
		void initialize(ifstream& sudokuGridIn);

        // Returns the square number in the sudoku grid; starts from index 1 in
		// the top left of the grid, and 9 in the bottom right
		int squareNumber(int i, int j);

		// Checks to see if a cell in a given sudoku grid is empty
		bool isBlank(int i, int j);

		// Returns the value in a given position of the sudoku grid
		int getCell(int i, int j);

		// Sets value in specific cell and updates the conflicts grid
		void setCell(int i, int j, int valueToWrite);

		// Resets value in specific cell and updates the conflicts grid
		void resetCell(int i, int j);

		// Checks to see if there are any conflicts that need to be updated
		void conflicts(int i, int j, int cellValue, string operation);

		// Prints the conflicts grid(s) to the console
		void printConflicts();

		// Returns true if the grid has no more empty cells; returns false
		// otherwise
		bool fullySolved();

	// Private members of Board Class
	private:
		// The maxtrix sudokuGrid go from 1 to BOARD_SIZE in each direction
		// i.e. the matrix size is (BOARD_SIZE + 1) by (BOARD_SIZE + 1)
		matrix<int> sudokuGrid;

		// Matrixes to store row, column, and square conflicts
		matrix<bool> conflictRows;
		matrix<bool> conflictColumns;
		matrix<bool> conflictSquares;
};


Board::Board()
// Default Constructor
{
	// Resizes each of the matrixes so that they reseble the size of a board
	sudokuGrid.resize(BOARD_SIZE + 1, BOARD_SIZE + 1);
	conflictRows.resize(BOARD_SIZE + 1, BOARD_SIZE + 1);
	conflictColumns.resize(BOARD_SIZE + 1, BOARD_SIZE + 1);
	conflictSquares.resize(BOARD_SIZE + 1, BOARD_SIZE + 1);

	// Clears sudoku grid to ensure all cells are empty before loading grid
	clear();
}// End default constructor


void Board::clear()
// Marks all cells in the sudoku grid as empty (BLANK_GRID_CELL_VAL)
// <FROM CANVAS>, modified by team
{
	for (int i = 1; i <= BOARD_SIZE; i++)
	// Iterates through each row
	{
		for (int j = 1; j <= BOARD_SIZE; j++)
		// Iterates through each column
		{
			// Sets all matrixes to default values
			sudokuGrid[i][j] = BLANK_GRID_CELL_VAL;
			conflictRows[i][j] = false;
			conflictColumns[i][j] = false;
			conflictSquares[i][j] = false;
		}// End column for
	}// End row for
}// End clear() function


void Board::print()
// Prints the current board. <FROM CANVAS>
{
    for (int i = 1; i <= BOARD_SIZE; i++)
    {
        if ((i - 1) % SQUARE_SIZE == 0)
        {
            cout << " -";
            for (int j = 1; j <= BOARD_SIZE; j++)
                cout << "---";
            cout << "-";
            cout << endl;
        }// End if
        for (int j = 1; j <= BOARD_SIZE; j++)
        {
            if ((j - 1) % SQUARE_SIZE == 0)
                cout << "|";
            if (!isBlank(i, j))
                cout << " " << getCell(i, j) << " ";
            else
                cout << "   ";
        }// End for
        cout << "|";
        cout << endl;
    }// End for

    cout << " -";
    for (int j = 1; j <= BOARD_SIZE; j++)
        cout << "---";
    cout << "-";
    cout << endl;
}// End print() function


void Board::initialize(ifstream& sudokuGridIn)
// Initializes a sudoku board and places all known values in the grid. If a
// value is not known, a '.' is read and no value is placed in the grid
// <FROM CANVAS>
{
	char ch;

	clear();

	for (int i = 1; i <= BOARD_SIZE; i++)
		for (int j = 1; j <= BOARD_SIZE; j++)
		{
			sudokuGridIn >> ch;

			// If the read char is not Blank
			if (ch != '.')
			{
				setCell(i, j, ch - '0');   // Convert char to int
			}// End if
		}// End for
}// End initialize() function


int Board::squareNumber(int i, int j)
// Return the square number of cell i,j (counting from left to right,
// top to bottom.  Note that i and j each go from 1 to BoardSize
// <FROM CANVAS>
{
	// Note that (int) i/SquareSize and (int) j/SquareSize are the x-y
	// coordinates of the square that i,j is in.  

	return SQUARE_SIZE * ((i - 1) / SQUARE_SIZE) + (j - 1) / SQUARE_SIZE + 1;
}// End squareNumber() function


bool Board::isBlank(int i, int j)
// Returns true if cell i,j is blank, and false otherwise. <FROM CANVAS>
{
	if (i < 1 || i > BOARD_SIZE || j < 1 || j > BOARD_SIZE)
		throw rangeError("bad value in setCell");

	return (getCell(i, j) == BLANK_GRID_CELL_VAL);
}// End isBlank() function


int Board::getCell(int i, int j)
// Returns the value stored in a cell.  Throws an exception
// if bad values are passed. <FROM CANVAS>
{
	if (i >= 1 && i <= BOARD_SIZE && j >= 1 && j <= BOARD_SIZE)
		return sudokuGrid[i][j];
	else
		throw rangeError("bad value in getCell");
}// End getCell() function


void Board::setCell(int i, int j, int valueToWrite)
// Sets a sudoku grid cell to a specific value (valueToWrite), then calls
// conflicts() to update the conflict matrixes
{
	// Sets value in sudoku grid to valueToWrite
	sudokuGrid[i][j] = valueToWrite;

	// Update conflicts
	conflicts(i, j, valueToWrite, "place");
}// End setCell() function


void Board::resetCell(int i, int j)
// Resets a sudoku grid cell to BLANK_GRID_CELL_VAL, then calls conflicts()
// to update the conflict matrixes
{
	// Needed to update conflicts
	int currentVal = getCell(i, j);

	// Set value in sudoku grid to BLANK_GRID_CELL_VAL
	sudokuGrid[i][j] = BLANK_GRID_CELL_VAL;

	// Update conflicts
	conflicts(i, j, currentVal, "remove");
}// End resetCell() function


void Board::conflicts(int i, int j, int cellValue, string operation)
// Based on the string 'operation', the conflicts matrixes are updated with
// the correct true/false information at a specific row, column, and square.
// Using the Improved Conflict Counts approach
{
	// Gets the current square number based on i and j
	int k = squareNumber(i, j);

	if (operation == "remove")
	// if the operation flag is remove, that means resetCell was called. Given
	// this, then the conflicts for the specific value in the column, row, and
	// square must be set to false
	{
		conflictRows[i][cellValue] = false;
		conflictColumns[j][cellValue] = false;
		conflictSquares[k][cellValue] = false;
	}// End 'remove' if
	else if (operation == "place")
	// if the operation flag is place, that means setCell was called. Given 
	// this, the conflicts for the specific value in the column, row, and 
	// square must be set to true
	{
		conflictRows[i][cellValue] = true;
		conflictColumns[j][cellValue] = true;
		conflictSquares[k][cellValue] = true;
	}// End 'place' if
}// End conflicts() function


void Board::printConflicts()
// Prints conflict matrixes to the console
{
	// Vector to store labels for printing
	vector<string> outputLabels = { "ROW", "COLUMN", "SQUARE" };

	cout << "\nPrinting Conflicts information: Values from left to right "
		 << "represent conflicts for value 1, 2, ..., 9. The given row, column"
		 << " or square conflicts are labeled where necessary. A value of '1' "
		 << "represents a conflict for the value in a specifc column, row, or"
		 << " square, and a value of '0' represents no conflict.";

	for (int z = 0; z < outputLabels.size(); z++)
	// Loops over ROW, COLUMN, and SQUARE labels
	{
		cout << "\n";

		for (int a = 1; a <= BOARD_SIZE; a++)
		// Loops over each row of the conflict matrixes
		{
			cout << "\n" << outputLabels[z] << " " << a << endl;

			for (int b = 1; b <= BOARD_SIZE; b++)
			// Loops over each column of the conflict matrixes
			{
				// Switch case to select the correct matrix (either row, column
				// or square)
				switch (z)
				{
					case 0:
					{
						cout << conflictRows[a][b] << " ";
						break;
					}
					case 1:
					{
						cout << conflictColumns[a][b] << " ";
						break;
					}
					case 2:
					{
						cout << conflictSquares[a][b] << " ";
						break;
					}
				}// End switch
			}// End column for
		}// End row for
	}// End outputLabels for
}// End printConflicts() function


bool Board::fullySolved()
// Returns true if the board is fully solved; returns false otherwise
{
	for (int i = 1; i <= BOARD_SIZE; i++)
	// Iterates through each row
	{
		for (int j = 1; j <= BOARD_SIZE; j++)
		// Iterates through each column
		{
			if (isBlank(i, j))
			// returns false if value returned represents a blank cell
			// getCell(i, j) == BLANK_GRID_CELL_VAL
			{
				return false;
			}// End if
		}// End column for
	}// End row for

	// If false wasn't returned, that means the grid has been fully solved;
	// return true as a result
	return true;
}// End fullySolved() function